public class House{
	//OPERATIONS
	public House(String anAddress, String aCity){...}
	public String getAddress(){...}
	public String getCity(){...}
	//ATTRIBUTES
	private String theAddress;
	private String theCity;
	private int theNumberOfRoom;
}


