public class Car{
	//OPERATIONS
	public Car(String aMake, String aModel, int aCapacity){...}
        public String getMake(){...}
	public String getModel(){...}
	public int getCapacity(){...}
	//ATTRIBUTES
	private String theMake;
	private String theModel;
	private int theCapacity;
}


