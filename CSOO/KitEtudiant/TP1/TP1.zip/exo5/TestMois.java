public class TestMois {
  public static void main(String args[]) {
    int monMois = Integer.parseInt(args[0]);
    //
    // code à fournir
    //
    System.out.print("Le mois de "
                     + moisJours[monMois].getNom() + " a ");
    System.out.println(moisJours[monMois].getNbJours()
                       + " jours");
  }
}
