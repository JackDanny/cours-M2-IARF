#!/bin/bash
cd '/home/jackdanny/Bureau/M2/cours-M2-IARF/RTIP/BE_Robotique/BE_Campana/gt' 


'/home/jackdanny/Bureau/BureauClean/MATLAB/bin/matlab' 


